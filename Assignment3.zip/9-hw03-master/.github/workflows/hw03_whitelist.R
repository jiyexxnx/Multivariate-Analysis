allowed_files = c("hw03.md",
                  "hw03.Rmd",
                  "hw03.pdf",
                  "hw03_corr.pdf",
                  "hw03.html",
                  "README.md",
                  "hw03.Rproj",
                  "hw03_whitelist.R",
                  "hw03.tex",
                  ".gitignore",
                  "images")

files = dir()
disallowed_files = files[!(files %in% allowed_files)]

if (length(disallowed_files != 0)) {
  cat("Disallowed files found:\n")
  cat("  (remove the following files from your repo)\n\n")

  for (file in disallowed_files)
    cat("*", file, "\n")

  quit("no", 1, FALSE)
}
