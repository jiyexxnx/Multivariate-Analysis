allowed_files = c("hw02.md",
                  "hw02.Rmd",
                  "hw02.pdf",
                  "hw02_corr.pdf",
                  "hw02.html",
                  "README.md",
                  "hw02.Rproj",
                  "hw02_whitelist.R",
                  "hw02.tex",
                  ".gitignore",
                  "images")

files = dir()
disallowed_files = files[!(files %in% allowed_files)]

if (length(disallowed_files != 0)) {
  cat("Disallowed files found:\n")
  cat("  (remove the following files from your repo)\n\n")

  for (file in disallowed_files)
    cat("*", file, "\n")

  quit("no", 1, FALSE)
}
